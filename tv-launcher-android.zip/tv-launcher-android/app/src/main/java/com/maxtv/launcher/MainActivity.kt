package com.maxtv.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ResolveInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.setBackgroundColor(0xFF0B0E17.toInt())
        web.addJavascriptInterface(Bridge(), "TV")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        web.evaluateJavascript("go('home')", null) // Home button pressed
    }

    override fun onBackPressed() { web.evaluateJavascript("go('home')", null) }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun leanbackApps(): List<ResolveInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != packageName }
    }

    inner class Bridge {
        @JavascriptInterface fun apps(): String =
            JSONArray(leanbackApps().map { it.loadLabel(packageManager).toString() }.distinct().sorted()).toString()

        @JavascriptInterface fun launch(label: String) = runOnUiThread {
            val r = leanbackApps().firstOrNull { it.loadLabel(packageManager).toString() == label }
            val i = r?.let { packageManager.getLeanbackLaunchIntentForPackage(it.activityInfo.packageName) }
            if (i != null) startActivity(i) else toast("Can't open $label")
        }

        // Opens the TV's own live-channel viewer (your scanned aerial channels).
        @JavascriptInterface fun liveTv() = runOnUiThread {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI))
            } catch (e: Exception) {
                val r = leanbackApps().firstOrNull {
                    val n = it.loadLabel(packageManager).toString().lowercase()
                    n.contains("live") || n == "tv"
                }
                val i = r?.let { packageManager.getLeanbackLaunchIntentForPackage(it.activityInfo.packageName) }
                if (i != null) startActivity(i) else toast("Couldn't find the Live TV app")
            }
        }

        @JavascriptInterface fun input(label: String) = runOnUiThread {
            val tm = getSystemService(TV_INPUT_SERVICE) as TvInputManager
            val info = tm.tvInputList.firstOrNull {
                it.isPassthroughInput && it.loadLabel(this@MainActivity).toString().contains(label, true)
            }
            if (info == null) {
                toast("No input named $label. Found: " + tm.tvInputList.joinToString { it.loadLabel(this@MainActivity).toString() })
                return@runOnUiThread
            }
            try {
                startActivity(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(info.id)))
            } catch (e: ActivityNotFoundException) { toast("Couldn't open $label") }
        }
    }
}
